package com.example.ztmdiary;

import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private TextView tvNotice,tvTip,tvDate;
    private EditText etPassword;
    private Button btLogin,btForgetThePassword,btWrite,btCheck,btManage,btChangePassword;
    private LinearLayout linearLayout0;
    private boolean LoginFlag = false;//是否登录的标志
    private int Number;//日记篇数
    private String TodayDate;//当天日期
    private String password;//登录密码
    private String[] Items = new String[1024];//对话框条目的数组
    private String[] Title=new String[1024];//日记标题的数组
    private String[] Date=new String[1024];//日记日期的数组
    private String[] Content=new String[1024];//日记内容的数组
    private String[] _ID = new String[1024];//对应主键值的数组
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findv();
        bindButton();

        ReceiveBroadcast_read();
        ReceiveBroadcast_manage();
        ReceiveBroadcast_delete();

        getpassword();

        btWrite.setVisibility(View.GONE);
        btCheck.setVisibility(View.GONE);
        btManage.setVisibility(View.GONE);
        btChangePassword.setVisibility(View.GONE);
        tvDate.setVisibility(View.GONE);
    }

    private void getpassword() {
        Password_Database helper = new Password_Database(MainActivity.this,MainActivity.this.getExternalFilesDir(null)+"/PasswordDataBase.db");
        SQLiteDatabase database= helper.getWritableDatabase();
        Cursor cursor = database.query("Password", null, null, null, null, null, null);
        if(cursor.getCount()==0){
            password="8888";//如果存放密码的数据库为空，则密码等于初始密码8888
            tvTip.setText(R.string.tip3);
        }else{
            cursor.moveToLast();
            password= cursor.getString(1) ;//如果存放密码的数据库不为空，则密码等于最后一次设置的密码
            tvTip.setText("Tip: 你已设置专属密码！");
        }
    }

    private void bindButton() {
        btLogin.setOnClickListener(this);
        btForgetThePassword.setOnClickListener(this);
        btWrite.setOnClickListener(this);
        btCheck.setOnClickListener(this);
        btManage.setOnClickListener(this);
        btChangePassword.setOnClickListener(this);
    }

    private void findv() {
        tvNotice = (TextView)findViewById(R.id.tvNotice);
        tvTip = (TextView)findViewById(R.id.tvTip);
        tvDate = (TextView)findViewById(R.id.tvDate);
        etPassword = (EditText)findViewById(R.id.etPassword);
        btLogin = (Button)findViewById(R.id.btLogin);
        btForgetThePassword = (Button)findViewById(R.id.btForgetThePassword);
        btWrite = (Button)findViewById(R.id.btWrite);
        btCheck = (Button)findViewById(R.id.btCheck);
        btManage = (Button)findViewById(R.id.btManage);
        btChangePassword=(Button)findViewById(R.id.btChangePassword);
        linearLayout0=(LinearLayout)findViewById(R.id.LinearLayout0);
    }

    @Override
    public void onClick(View v) {
        if(LoginFlag==false){
            switch (v.getId()){
                case R.id.btLogin:
                    if(etPassword.getText().toString().equals(password)){
                        etPassword.setText("");
                        linearLayout0.setBackground(getDrawable(R.drawable.background2));
                        tvNotice.setText("Welcome! 在这里可以记录你的心事或者身边发生的小故事,希望你能每天开心！");

                        getTodayDate();

                        tvDate.setText("今天是"+TodayDate);
                        tvDate.setVisibility(View.VISIBLE);

                        LoginFlag = true;
                        etPassword.setVisibility(View.GONE);
                        btLogin.setVisibility(View.GONE);
                        btForgetThePassword.setVisibility(View.GONE);
                        tvTip.setVisibility(View.GONE);
                        btWrite.setVisibility(View.VISIBLE);
                        btCheck.setVisibility(View.VISIBLE);
                        btManage.setVisibility(View.VISIBLE);
                        btChangePassword.setVisibility(View.VISIBLE);
                    }
                    else{
                        Toast_center(MainActivity.this,"密码错误！(如果你不是本人，请立即离开!)");
                    }
                    break;
                case R.id.btForgetThePassword:

                    if(password.equals("8888")){
                        Toast_center(MainActivity.this,"当前密码为初始密码8888");
                    }else{
                        createQuestionDialog2();
                    }
                    break;
            }

        }else{

            switch(v.getId()){
                case R.id.btWrite:
                    Intent intent_write = new Intent();
                    intent_write.setClass(MainActivity.this, Write_Read.class);

                    intent_write.putExtra("Flag","write");

                    intent_write.putExtra("Title","");
                    intent_write.putExtra("Date",TodayDate);
                    intent_write.putExtra("Content","");
                    startActivityForResult(intent_write,1);
                    break;

                case R.id.btCheck:
                    Intent intent_read = new Intent();

                    intent_read.putExtra("Flag","read");

                    intent_read.setClass(MainActivity.this, IntentService_database.class);
                    startService(intent_read);
                    break;
                case R.id.btManage:
                    Intent intent_manage = new Intent();

                    intent_manage.putExtra("Flag","manage");

                    intent_manage.setClass(MainActivity.this,IntentService_database.class);
                    startService(intent_manage);
                    break;
                case R.id.btChangePassword:
                    Answer_Database helper = new Answer_Database(MainActivity.this,MainActivity.this.getExternalFilesDir(null)+"/AnswerDataBase.db");
                    SQLiteDatabase database= helper.getWritableDatabase();
                    Cursor cursor = database.query("Answer", null, null, null, null, null, null);
                    if(cursor.getCount()==0){
                        createQuestionDialog1();
                    }else{
                        createEditTextDialog();
                    }

                    break;
            }
        }

    }



    private void ReceiveBroadcast_read() {
        Receiver_Read receiver_read = new Receiver_Read();
        IntentFilter Filter_read=new IntentFilter();
        Filter_read.addAction("Read");
        registerReceiver(receiver_read,Filter_read);
    }
    private void ReceiveBroadcast_manage() {
        Receiver_Manage receiver_manage = new Receiver_Manage();
        IntentFilter Filter_manage=new IntentFilter();
        Filter_manage.addAction("manage");
        registerReceiver(receiver_manage,Filter_manage);
    }
    private void ReceiveBroadcast_delete() {
        Receiver_Delete receiver_delete = new Receiver_Delete();
        IntentFilter Filter_delete=new IntentFilter();
        Filter_delete.addAction("delete");
        registerReceiver(receiver_delete,Filter_delete);
    }

    private void getTodayDate() {
        Date date=new Date(System.currentTimeMillis());
        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy年MM月dd日");
        TodayDate = (String)simpleDateFormat.format(date);
    }//获取到当天的日期

    private void Toast_center(Context context, String string) {
        Toast toast = Toast.makeText(context, string, Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();
    }//自定义弹窗函数，弹窗位置设为页面中心

    private void createQuestionDialog1() {
        Log.i("TAG","创建设置密保问题的对话框");

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("请设置密保问题,用于重置密码");

        View layout = getLayoutInflater().inflate(R.layout.resetpassword_question,null);
        builder.setView(layout);

        builder.setPositiveButton("确认", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Answer_Database helper = new Answer_Database(MainActivity.this,MainActivity.this.getExternalFilesDir(null)+"/AnswerDataBase.db");
                SQLiteDatabase database= helper.getWritableDatabase();

                EditText etPhoneNumber=(EditText)layout.findViewById(R.id.etPhoneNumber);
                EditText etQQNumber=(EditText)layout.findViewById(R.id.etQQNumber);
                EditText etSports=(EditText)layout.findViewById(R.id.etSports);

                ContentValues value = new ContentValues();//用于装载一行新的数据
                value.put("answer1",etPhoneNumber.getText().toString());
                value.put("answer2",etQQNumber.getText().toString());
                value.put("answer3",etSports.getText().toString());
                long i=database.insert("Answer", null, value);//插入表格
                Log.i("TAG", String.valueOf(i)+etPhoneNumber.getText().toString()+etQQNumber.getText().toString()+etSports.getText().toString());

                database.close();
            }
        });
        builder.create().show();
    }

    private void createQuestionDialog2() {
        Log.i("TAG","创建重置密码回答问题的对话框");
        Answer_Database helper = new Answer_Database(MainActivity.this,MainActivity.this.getExternalFilesDir(null)+"/AnswerDataBase.db");
        SQLiteDatabase database= helper.getWritableDatabase();
        Cursor cursor = database.query("Answer", null, null, null, null, null, null);
        cursor.moveToLast();
        String answer1= cursor.getString(1) ;
        String answer2=cursor.getString(2);
        String answer3=cursor.getString(3);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("请回答以下问题");

        View layout = getLayoutInflater().inflate(R.layout.resetpassword_question,null);
        builder.setView(layout);

        builder.setPositiveButton("重置密码", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                EditText etPhoneNumber=(EditText)layout.findViewById(R.id.etPhoneNumber);
                EditText etQQNumber=(EditText)layout.findViewById(R.id.etQQNumber);
                EditText etSports=(EditText)layout.findViewById(R.id.etSports);
                if(etPhoneNumber.getText().toString().equals(answer1)
                        &etQQNumber.getText().toString().equals(answer2)
                        &etSports.getText().toString().equals(answer3)){
                    Password_Database Helper = new Password_Database(MainActivity.this,MainActivity.this.getExternalFilesDir(null)+"/PasswordDataBase.db");
                    SQLiteDatabase Database= Helper.getWritableDatabase();
                    Database.delete("Password",null,null);
                    Database.close();

                    Toast_center(MainActivity.this,"成功重置密码为初始密码8888！");

                    getpassword();
                }else{
                    Toast_center(MainActivity.this,"问题回答错误,请重试！");
                }

            }
        });
        builder.create().show();

    }



    private void createListDialog() {
        Log.i("TAG","创建列表对话框");
        Intent intent = new Intent();
        intent.setClass(MainActivity.this, Write_Read.class);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("请选择要查看的日记");
        CreatItems();
        String[] items= Arrays.copyOfRange(Items,0,Number);//列表项数组
        builder.setItems(items,new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                intent.putExtra("Flag","check");
                intent.putExtra("Title",Title);
                intent.putExtra("Date",Date);
                intent.putExtra("Content",Content);
                intent.putExtra("_ID",_ID);
                intent.putExtra("Number",Number);
                intent.putExtra("which",which);
                Log.i("TAG", String.valueOf(which));
                startActivityForResult(intent,1);
            }
        });
        builder.setPositiveButton("添加新日记", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                intent.putExtra("Flag","write");
                intent.putExtra("Title","");
                intent.putExtra("Date",TodayDate);
                intent.putExtra("Content","");
                startActivityForResult(intent,1);
            }
        });
        builder.create().show();
    }

    private void CreatItems() {
        for(int i=0;i<Number;i++){
            Items[i]="("+(i+1)+")  "+Title[i]+"        ---"+Date[i];
        }
    }

    private void createMultiChoiceDialog() {
        Log.i("TAG","创建多选对话框");
        AlertDialog.Builder bd = new AlertDialog.Builder(this);
        CreatItems();
        String[] items= Arrays.copyOfRange(Items,0,Number);
        boolean[] selected = new boolean[Number];
        for (int i = 0; i < selected.length; i++) {
            selected[i] = false;
        }
        bd.setTitle("请选择要删除的日记");
        bd.setMultiChoiceItems(items, selected, new DialogInterface.OnMultiChoiceClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which, boolean isChecked) {

            }
        });
        bd.setPositiveButton("删除", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                int j=0;
                String[] Where = new String[selected.length];
                for(int i=0;i<selected.length;i++){
                    if(selected[i]==true){
                        Where[j]=_ID[i];
                        j++;
                    }
                }
                String[] where= Arrays.copyOfRange(Where,0,j);

                Intent intent_delete = new Intent();
                intent_delete.putExtra("Flag","delete");
                intent_delete.putExtra("_ID",where);
                intent_delete.setClass(MainActivity.this, IntentService_database.class);
                startService(intent_delete);
            }
        });
        bd.create().show();

    }

    private void createEditTextDialog() {
        Log.i("TAG","创建文本输入对话框");
        AlertDialog.Builder bd = new AlertDialog.Builder(this);
        bd.setTitle("请输入要设置的密码");
        View layout = getLayoutInflater().inflate(R.layout.newpassword_input,null);
        bd.setView(layout);
        bd.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                EditText etNewPassword=layout.findViewById(R.id.etNewPassword);
                String txt = etNewPassword.getText().toString();
                Pattern p = Pattern.compile("[a-zA-Z0-9]*");
                Matcher m = p.matcher(txt);
                if(txt.isEmpty()){
                    Toast_center(MainActivity.this,"修改失败,密码不能为空!");
                }else if(txt.equals("8888")){
                    Toast_center(MainActivity.this,"修改失败,请不要设置密码为初始密码！");
                }else if(m.matches()){
                    Password_Database helper = new Password_Database(MainActivity.this,MainActivity.this.getExternalFilesDir(null)+"/PasswordDataBase.db");
                    SQLiteDatabase database= helper.getWritableDatabase();
                    ContentValues value = new ContentValues();//用于装载一行新的数据
                    value.put("password",etNewPassword.getText().toString());
                    Log.i("TAG","新密码是"+etNewPassword.getText().toString());
                    database.insert("Password", null, value);
                    database.close();

                    Toast_center(MainActivity.this,"密码修改成功,请重新登录！");
                    linearLayout0.setBackground(getDrawable(R.drawable.background1));
                    LoginFlag = false;
                    getpassword();
                    tvNotice.setText(R.string.tip1);
                    etPassword.setVisibility(View.VISIBLE);
                    btLogin.setVisibility(View.VISIBLE);
                    btForgetThePassword.setVisibility(View.VISIBLE);
                    tvTip.setVisibility(View.VISIBLE);
                    btWrite.setVisibility(View.GONE);
                    btCheck.setVisibility(View.GONE);
                    btManage.setVisibility(View.GONE);
                    btChangePassword.setVisibility(View.GONE);
                    tvDate.setVisibility(View.GONE);
                }else{
                    Toast_center(MainActivity.this,"修改失败,密码只能由数字和字母组成！");
                }
            }
        });
        bd.create().show();

    }


    public class Receiver_Read extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            // TODO: This method is called when the BroadcastReceiver is receiving
            // an Intent broadcast.
            Log.i("TAG", "Receiver_Read响应");
            Title = intent.getStringArrayExtra("Title");//获取日记标题的数组
            Date = intent.getStringArrayExtra("Date");//获取日记的日期的数组
            Content = intent.getStringArrayExtra("Content");//获取日记内容的数组
            Number = intent.getIntExtra("Number",0);//获取日记篇数
            _ID = intent.getStringArrayExtra("_ID");//获得对应主键值的数组

            createListDialog();//创建列表对话框

            Toast toast = Toast.makeText(context, "查询到"+Number+"条数据", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.TOP, 0, 300);
            toast.show();//弹窗显示查询到多少篇日记
        }

    }

    public class Receiver_Manage extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            // TODO: This method is called when the BroadcastReceiver is receiving
            // an Intent broadcast.
            Log.i("TAG", "Receiver_Manage响应");
            Title = intent.getStringArrayExtra("Title");//获取日记标题的数组
            Date = intent.getStringArrayExtra("Date");//获取日记日期的数组
            Number = intent.getIntExtra("Number",0);//获取日记篇数
            _ID = intent.getStringArrayExtra("_ID");//获得对应主键值的数组

            createMultiChoiceDialog();//创建多选对话框

        }

    }
    public class Receiver_Delete extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            // TODO: This method is called when the BroadcastReceiver is receiving
            // an Intent broadcast.
            Log.i("TAG", "Receiver_Delete响应");

            Toast_center(context,"已删除"+intent.getIntExtra("o",0)+"条数据");//弹窗显示删除多少篇日记

        }

    }


}