package com.example.ztmdiary;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Answer_Database extends SQLiteOpenHelper {
    public Answer_Database(@Nullable Context context, @Nullable String name) {//实例化方法
        super(context, name, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {//重要！数据库创建格式
        String DATABASE_SQL = "CREATE TABLE " + "Answer" + " (" + "_ID" + " INTEGER primary key autoincrement, " + "answer1" + " text not null, " + "answer2"
                + " text not null, " + "answer3" + " text not null " + ");";
        db.execSQL(DATABASE_SQL);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
}
