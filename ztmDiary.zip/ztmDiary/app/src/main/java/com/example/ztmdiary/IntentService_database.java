package com.example.ztmdiary;

import android.app.IntentService;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

/**
 * An {@link IntentService} subclass for handling asynchronous task requests in
 * a service on a separate handler thread.
 * <p>
 * <p>
 * TODO: Customize class - update intent actions, extra parameters and static
 * helper methods.
 */
public class IntentService_database extends IntentService {

    // TODO: Rename actions, choose action names that describe tasks that this
    // IntentService can perform, e.g. ACTION_FETCH_NEW_ITEMS
    private static final String ACTION_FOO = "com.example.ztmdiary.action.FOO";
    private static final String ACTION_BAZ = "com.example.ztmdiary.action.BAZ";

    // TODO: Rename parameters
    private static final String EXTRA_PARAM1 = "com.example.ztmdiary.extra.PARAM1";
    private static final String EXTRA_PARAM2 = "com.example.ztmdiary.extra.PARAM2";
    private int Number;
    private String[] Title=new String[1024];
    private String[] Date=new String[1024];
    private String[] Content=new String[1024];
    private String[] _ID = new String[1024];

    public IntentService_database() {
        super("IntentService_write");
    }

    /**
     * Starts this service to perform action Foo with the given parameters. If
     * the service is already performing a task this action will be queued.
     *
     * @see IntentService
     */
    // TODO: Customize helper method
    public static void startActionFoo(Context context, String param1, String param2) {
        Intent intent = new Intent(context, IntentService_database.class);
        intent.setAction(ACTION_FOO);
        intent.putExtra(EXTRA_PARAM1, param1);
        intent.putExtra(EXTRA_PARAM2, param2);
        context.startService(intent);
    }

    /**
     * Starts this service to perform action Baz with the given parameters. If
     * the service is already performing a task this action will be queued.
     *
     * @see IntentService
     */
    // TODO: Customize helper method
    public static void startActionBaz(Context context, String param1, String param2) {
        Intent intent = new Intent(context, IntentService_database.class);
        intent.setAction(ACTION_BAZ);
        intent.putExtra(EXTRA_PARAM1, param1);
        intent.putExtra(EXTRA_PARAM2, param2);
        context.startService(intent);
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        Diary_Database helper = new Diary_Database(IntentService_database.this, IntentService_database.this.getExternalFilesDir(null) + "/myDataBase.db");//按照数据库类的格式，声明并实例化数据库
        SQLiteDatabase database = helper.getWritableDatabase();

        if(intent.getStringExtra("Flag").equals("write")){
            Log.i("TAG","IntentService_write启动");

            ContentValues value1 = new ContentValues();//用于装载一行新的数据
            value1.put("Title",intent.getStringExtra("Title"));
            value1.put("Date",intent.getStringExtra("Date"));
            value1.put("Content",intent.getStringExtra("Content"));
            long i = database.insert("MyDiary", null, value1);//插入表格
            if (i == -1) {
                Log.i("TAG","添加失败");
            } else {
                Log.i("TAG","添加成功");
            }

            SendBroadcast_write(i);
            Log.i("TAG","write广播发送");

            database.close();
        }else if(intent.getStringExtra("Flag").equals("update")){
            Log.i("TAG","IntentService_update启动");
            ContentValues value2 = new ContentValues();//装载更新数据
            value2.put("Title", intent.getStringExtra("Title"));
            value2.put("Date", intent.getStringExtra("Date"));
            value2.put("Content",intent.getStringExtra("Content"));

            String where = "_ID"+"="+intent.getStringExtra("_ID");
            database.update("MyDiary", value2, where, null);
            Log.i("TAG","保存成功");
            SendBroadcast_update();
            Log.i("TAG","update广播发送");

            database.close();
        }else if(intent.getStringExtra("Flag").equals("read")){
            Log.i("TAG","IntentService_read启动");
            Cursor cursor = database.query("MyDiary", null, null, null, null, null, null);
            Number=cursor.getCount();
            if (Number > 0)//如果查询的结果不为空
            {
                Log.i("TAG","查询到"+Number+"条数据");
                int j=0;
                while (cursor.moveToNext())//当指针尚未到最后一行时，执行循环
                {
                    _ID[j] = cursor.getString(0);
                    Title[j] = cursor.getString(1) ;//获取内容并记住
                    Date[j] = cursor.getString(2) ;
                    Content[j] = cursor.getString(3) ;
                    j++;
                }
            } else {
                Log.i("TAG","查询到0条数据");
            }
            SendBroadcast_Read();
            Log.i("TAG","read广播发送");

            cursor.close();
            database.close();
        } else if(intent.getStringExtra("Flag").equals("manage")){
            Log.i("TAG","IntentService_manage启动");
            Cursor cursor1 = database.query("MyDiary", null, null, null, null, null, null);
            Number=cursor1.getCount();
            if (Number > 0)//如果查询的结果不为空
            {
                Log.i("TAG","查询到"+Number+"条数据");
                int j=0;
                while (cursor1.moveToNext())//当指针尚未到最后一行时，执行循环
                {
                    _ID[j] = cursor1.getString(0);
                    Title[j] = cursor1.getString(1) ;//获取内容并记住
                    Date[j] = cursor1.getString(2) ;
                    j++;
                }
            } else {
                Log.i("TAG","查询到0条数据");
            }
            SendBroadcast_manage();
            Log.i("TAG","manage广播发送");

            cursor1.close();
            database.close();
        } else if(intent.getStringExtra("Flag").equals("delete")){
            Log.i("TAG","IntentService_delete启动");
            int o=0;
            String[] where2 = intent.getStringArrayExtra("_ID");
            for(int i=0;i<where2.length;i++){
                o = o + database.delete("MyDiary", "_ID"+"="+where2[i],null);//删除对应Title的那一行
            }
            SendBroadcast_delete(o);
            Log.i("TAG","delete广播发送");
            database.close();
        }

    }


    private void SendBroadcast_write(long i) {
        Intent intent = new Intent();
        intent.putExtra("i",i);
        intent.setAction("write");
        sendBroadcast(intent);
    }
    private void SendBroadcast_update() {
        Intent intent = new Intent();
        intent.setAction("update");
        sendBroadcast(intent);
    }
    private void SendBroadcast_Read() {
        Intent intent = new Intent();
        intent.putExtra("_ID",_ID);
        intent.putExtra("Title",Title);
        intent.putExtra("Date",Date);
        intent.putExtra("Content",Content);
        intent.putExtra("Number",Number);
        intent.setAction("Read");
        sendBroadcast(intent);
    }
    private void SendBroadcast_manage() {
        Intent intent = new Intent();
        intent.putExtra("Title",Title);
        intent.putExtra("Date",Date);
        intent.putExtra("Number",Number);
        intent.putExtra("_ID",_ID);
        intent.setAction("manage");
        sendBroadcast(intent);
    }
    private void SendBroadcast_delete(int o) {
        Intent intent = new Intent();
        intent.putExtra("o",o);
        intent.setAction("delete");
        sendBroadcast(intent);
    }

    /**
     * Handle action Foo in the provided background thread with the provided
     * parameters.
     */
    private void handleActionFoo(String param1, String param2) {
        // TODO: Handle action Foo
        throw new UnsupportedOperationException("Not yet implemented");
    }

    /**
     * Handle action Baz in the provided background thread with the provided
     * parameters.
     */
    private void handleActionBaz(String param1, String param2) {
        // TODO: Handle action Baz
        throw new UnsupportedOperationException("Not yet implemented");
    }
}