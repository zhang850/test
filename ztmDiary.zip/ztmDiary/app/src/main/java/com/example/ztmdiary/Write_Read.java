package com.example.ztmdiary;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Write_Read extends AppCompatActivity implements View.OnClickListener {
    private TextView tvDate;
    private EditText etTitle,etWrite;
    private Button btClear,btSave,btUpdate,btLast,btNext;
    private LinearLayout linearLayout1;
    private String TodayDate;
    private int which,Number;
    private String[] Title=new String[1024];
    private String[] Date=new String[1024];
    private String[] Content=new String[1024];
    private String[] _ID = new String[1024];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_write);


        findv();
        bindButton();

        getTodayDate();

        ReceiveBroadcast_write();
        ReceiveBroadcast_update();



        if(this.getIntent().getStringExtra("Flag").equals("check")){
            which=this.getIntent().getIntExtra("which",0);
            Number=this.getIntent().getIntExtra("Number",0);
            _ID=this.getIntent().getStringArrayExtra("_ID");
            Title=this.getIntent().getStringArrayExtra("Title");
            Date=this.getIntent().getStringArrayExtra("Date");
            Content=this.getIntent().getStringArrayExtra("Content");

            etTitle.setText(Title[which]);
            tvDate.setText(Date[which]);
            etWrite.setText(Content[which]);
            btSave.setVisibility(View.GONE);

        }else if(this.getIntent().getStringExtra("Flag").equals("write")){
            etTitle.setText(this.getIntent().getStringExtra("Title"));
            tvDate.setText(this.getIntent().getStringExtra("Date"));
            etWrite.setText(this.getIntent().getStringExtra("Content"));
            linearLayout1.setVisibility(View.GONE);
        }
    }


    private void bindButton() {
        btClear.setOnClickListener(this);
        btSave.setOnClickListener(this);
        btUpdate.setOnClickListener(this);
        btLast.setOnClickListener(this);
        btNext.setOnClickListener(this);
    }

    private void findv() {
        etTitle = (EditText)findViewById(R.id.etTitle);
        tvDate = (TextView)findViewById(R.id.tvDate);
        etWrite = (EditText)findViewById(R.id.etWrite);
        btClear = (Button)findViewById(R.id.btClear);
        btSave = (Button)findViewById(R.id.btSave);
        btUpdate = (Button)findViewById((R.id.btUpdate));
        btLast=(Button)findViewById(R.id.btLast);
        btNext=(Button)findViewById(R.id.btNext);
        linearLayout1=(LinearLayout)findViewById(R.id.LinearLayout1);
    }

    @Override
    public void onClick(View v) {

        switch(v.getId()){
            case R.id.btClear://清空
                etTitle.setText("");
                etWrite.setText("");
                break;
            case R.id.btSave://保存，启动intentservice,对数据库进行insert操作
                if(etTitle.getText().toString().isEmpty()){
                    Toast_center(Write_Read.this,"标题不能为空");
                }else {

                    Intent intent_write = new Intent();

                    intent_write.putExtra("Title",etTitle.getText().toString());
                    intent_write.putExtra("Date",TodayDate);
                    intent_write.putExtra("Content",etWrite.getText().toString());
                    intent_write.putExtra("Flag","write");
                    intent_write.setClass(Write_Read.this, IntentService_database.class);
                    startService(intent_write);

                }
                break;
            case R.id.btLast://查看上一篇日记
                if(which==0){
                    Toast_center(Write_Read.this,"这已经是第一篇日记！");
                }else{
                    which--;
                    etTitle.setText(Title[which]);
                    tvDate.setText(Date[which]);
                    etWrite.setText(Content[which]);
                }

                break;

            case R.id.btNext://查看下一篇日记
                if(which==(Number-1)){
                    Toast_center(Write_Read.this,"这已经是最后一篇日记！");
                }else{
                    which++;
                    etTitle.setText(Title[which]);
                    tvDate.setText(Date[which]);
                    etWrite.setText(Content[which]);
                }
                break;

            case R.id.btUpdate://对查看的日记进行更新操作
                Log.i("TAG","btUpdate");
                if(etTitle.getText().toString().isEmpty()&etWrite.getText().toString().isEmpty()){
                    Diary_Database helper = new Diary_Database(Write_Read.this, Write_Read.this.getExternalFilesDir(null) + "/myDataBase.db");//按照数据库类的格式，声明并实例化数据库
                    SQLiteDatabase database = helper.getWritableDatabase();
                    database.delete("MyDiary", "_ID"+"="+_ID[which],null);//删除对应Title的那一行
                    database.close();
                    Toast_center(Write_Read.this,"日记已被删除");
                    Write_Read.this.setResult(1);
                    Write_Read.this.finish();

                }else if(etTitle.getText().toString().isEmpty()&(!etWrite.getText().toString().isEmpty())){
                    Toast_center(Write_Read.this,"标题不能为空");
                }else  {

                    Intent intent_update = new Intent();

                    intent_update.putExtra("Title", etTitle.getText().toString());
                    intent_update.putExtra("Date",TodayDate);
                    intent_update.putExtra("Content", etWrite.getText().toString());
                    intent_update.putExtra("_ID",_ID[which]);
                    intent_update.putExtra("Flag","update");
                    intent_update.setClass(Write_Read.this, IntentService_database.class);
                    startService(intent_update);

                }
                break;

            default:
                break;
        }
    }

    private void getTodayDate() {
        Date date=new Date(System.currentTimeMillis());
        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy年MM月dd日");
        TodayDate = (String)simpleDateFormat.format(date);
    }

    private void Toast_center(Context context, String string) {
        Toast toast = Toast.makeText(context, string, Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();
    }

    private void ReceiveBroadcast_write() {
        Receiver_write receiver_write = new Receiver_write();
        IntentFilter Filter_write=new IntentFilter();
        Filter_write.addAction("write");
        registerReceiver(receiver_write,Filter_write);
    }
    private void ReceiveBroadcast_update() {
        Receiver_update receiver_update = new Receiver_update();
        IntentFilter Filter_update=new IntentFilter();
        Filter_update.addAction("update");
        registerReceiver(receiver_update,Filter_update);
    }


    public class Receiver_write extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            // TODO: This method is called when the BroadcastReceiver is receiving
            // an Intent broadcast.
            Log.i("TAG", "Receiver_write响应");
            if(intent.getLongExtra("i",0L)==-1) {
                Toast_center(context,"保存失败");
            }else{
                Toast_center(context,"保存成功");
            }

            Write_Read.this.setResult(1);
            Write_Read.this.finish();
        }
    }

    public class Receiver_update extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            // TODO: This method is called when the BroadcastReceiver is receiving
            // an Intent broadcast.
            Log.i("TAG","ReceiveBroadcast_update响应");
            Toast_center(context,"保存成功");

            Write_Read.this.setResult(2);
            Write_Read.this.finish();
        }
    }


}

